<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 
/*
 * Copyright (c) 2006-2017 Adipati Arya <jawircodes@gmail.com>,
 * 2006-2017 http://sshcepat.com
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
class User_model extends CI_Model {
	public function __construct() {
		
		parent::__construct();
		$this->load->database();
	}
	public function create_user($username, $email, $password) {
		
		$data = array(
			'username'   => $username,
			'email'      => $email,
			'password'   => $this->hash_password($password),
			'created_at' => date('d-m-Y'),
		);
		
		return $this->db->insert('users', $data);
		
	}
	public function create_hostname($array) {
		return $this->db->insert('server', $array);
	}
	public function resolve_user_login($username, $password) {
		
		$this->db->select('password');
		$this->db->from('users');
		$this->db->where('username', $username);
		$hash = $this->db->get()->row('password');
		
		return $this->verify_password_hash($password, $hash);
	}
	
	public function get_user_id_from_username($username) {
		
		$this->db->select('id');
		$this->db->from('users');
		$this->db->where('username', $username);

		return $this->db->get()->row('id');
	}
	public function get_user_id_from_ssh($user, $hostid) {
		
		$this->db->select('id');
		$this->db->from('sshuser');
		$this->db->where('username', $user);
		$this->db->where('serverid', $hostid);
		return $this->db->get()->row('id');
	}
	public function get_user_ssh($hostid) {
		$query = $this->db->get_where('sshuser', array('serverid' => $hostid));
		$arr = array();
		foreach ($query->result_array() as $row) {
			$tmp = array(
				'id' => $row['id'],
				'username' => $row['username'],
				'password' => $row['password'],
				'hostname' => $row['hostname'],
				'created_by' => $row['created_by'],
				'created_at' => $row['created_at'],
				'expired_at' => $row['expired_at'],
			);
			array_push($arr, $tmp);
		}
		return $arr;
	}
	
	public function seller_notify() {
		$arr = array();
		foreach ($this->db->get_where('deposit', array('is_confirmed' => false)) -> result_array() as $row) {
			
			$tmp = array (
						'id' => $row['id'],
						'userid' => $row['userid'],
						'username' => $this->get_user($row['userid'])->username,
						'pesan' => $row['pesan'],
						'created_at' => $row['created_at']
						);
			array_push($arr, $tmp);
		}
		return $arr; 
	}
	private function _get_seller_msg($id) {
		
		$this->db->from('deposit');
		$this->db->where('id', $id);
		
		return $this->db->get()->row();
	}
	public function id_ssh($id) {
		
		$this->db->from('sshuser');
		$this->db->where('id', $id);
		
		return $this->db->get()->row();
	}
	public function update_message($id,$cmd) {
		$this->db->where('id', $id);	
		if ($cmd == 'konfirm') {
			if ($this->db->update('deposit', array('is_confirmed' => true))) {
						$saldo = $this -> _get_seller_msg($id) -> jumlah;
						$username= $this->get_user($this -> _get_seller_msg($id) -> userid)->username;
						$total = $this->get_user($this -> _get_seller_msg($id) -> userid)->saldo + $saldo;
						return $this->update_saldo($username, $total);
				}
		}
		elseif ($cmd =='del') { return $this->db->delete('deposit', array('id' => $id)); }
		else {show_404();}
	}
	public function get_user($user_id) {
		
		$this->db->from('users');
		$this->db->where('id', $user_id);
		return $this->db->get()->row();
	}
	
	
	private function hash_password($password) {
		return password_hash($password, PASSWORD_BCRYPT);
	}
	private function verify_password_hash($password, $hash) {
		return password_verify($password, $hash);
	}
	public function get_hostname($id=FALSE) {
		if ($id === FALSE) {return $this->db->get('server')->result_array(); }
		
		$this->db->from('server');
		$this->db->where('Id', $id);
		return $this->db->get()->row();
	}
	public function update_server($post, $id) {
		$this->db->where('Id', $id);
		return $this->db->update('server', $post);
	}
	public function delete_server($id) {
		$this->db->where('Id', $id);
		return $this->db->delete('server', array('Id' => $id));
	}
	public function update_login($post) {
		$data = array('password' => $this->hash_password($post['password']));
		$this->db->where('username', $post['username']);
		return $this->db->update('users', $data);
	}
	public function update_saldo($user, $saldo) {
		$this->db->where('username', $user);
		return $this->db->update('users', array('username' => $user, 'saldo'=>$saldo,));
	}
	
	public function user_ssh($user, $password, $host, $create, $expired, $id, $price) {
		
		$data = array(
			'username'   => $user,
			'password'   => $password,
			
			'hostname'      => $host,
			'created_by'   => $create,
			'expired_at' => date("Y,m,d",strtotime("+".$expired." days", time() ) ),
			'created_at' => date('Y,m,d'),
			'serverid' => $id,
			'price' => $price,
		);
		
		
		return $this->db->insert('sshuser', $data);
		
	}
	public function deposit($userid, $pesan, $jumlah) {
		
		$data = array(
			'userid'   => $userid,
			'pesan'      => $pesan,
			'jumlah' => $jumlah,
			'created_at' => date('Y-m-j H:i:s')
		);
		
		return $this->db->insert('deposit', $data);
		
	}
	public function delete_user_ssh($id) {
		$this->db->where('id', $id);
		return $this->db->delete('sshuser', array('id' => $id));
	}
	
	
	public function view_asset() {
		return $this->db->get('asset')->result_array();
	}
	
	
	public function view_users() {
		return $this->db->get('users')->result_array();
	}
	
	public function get_hp($hp) {
		
		$this->db->select('id');
		$this->db->from('asset');
		$this->db->where('link', $hp);
		return $this->db->get()->row('id');
	}

	public function asset($data) {
		return $this->db->update('asset', $data);
	}
	
	public function get_req($req) {
		
		$this->db->select('id');
		$this->db->from('asset');
		$this->db->where('rekening', $req);

		return $this->db->get()->row('id');
	}
	
	public function get_account_list($user) {
		return $this->db->get_where('sshuser', array('created_by' => $user))->result_array();
	}
	
	
	public function view_user($user) {
		return $this->db->get_where('users', array('username' => $user))->result_array();
	}
	
	public function view_server($user) {
		return $this->db->get_where('server', array('HostName' => $user))->result_array();
	}
	
	public function get_country() {
		$query = $this->db->get('country');
		return $query->result_array();
	}
	///
	public function get_wallet($hp) {
		
		$this->db->select('id');
		$this->db->from('wallet');
		$this->db->where('phone', $hp);
		return $this->db->get()->row('id');
	}

	public function wallet($data) {
		return $this->db->update('wallet', $data);
	}
	
	public function view_wallet() {
		return $this->db->get('wallet')->result_array();
	}
	
	public function view_account() {
		return $this->db->get('sshuser')->result_array();
	}
	
public function view_sshuser($user) {
		return $this->db->get_where('sshuser', array('HostName' => $user))->result_array();
	}
	
	//token_line
	public function get_token($hp) {
		
		$this->db->select('id');
		$this->db->from('token');
		$this->db->where('login', $hp);
		return $this->db->get()->row('id');
	}


public function token($data) {
		return $this->db->update('token', $data);
	}

public function view_token() {
		return $this->db->get('token')->result_array();
	}
	
	
//ovpn_download
	public function get_ovpn($hp) {
		
		$this->db->select('id');
		$this->db->from('ovpn');
		$this->db->where('link', $hp);
		return $this->db->get()->row('id');
	}


public function ovpn($data) {
		return $this->db->insert('ovpn', $data);
	}

public function view_ovpn() {
		return $this->db->get('ovpn')->result_array();
	}
	
	public function del_ovpn($id) {
		$this->db->where('id', $id);
		return $this->db->delete('ovpn', array('id' => $id));
	}
	
	//msg
	public function get_msg($hp) {
		
		$this->db->select('id');
		$this->db->from('masseg');
		$this->db->where('post', $hp);
		return $this->db->get()->row('id');
	}


public function msg($data) {
		return $this->db->update('masseg', $data);
	}
	

public function view_msg() {
		return $this->db->get('masseg')->result_array();
	}
	
	///??????????

	public function get_profile($hp) {
		
		$this->db->select('id');
		$this->db->from('users');
		$this->db->where('png', $_SESSION['username']);
		return $this->db->get()->row('id');
	}

public function edit_user($post) {
		$data = array('png' => $post);
		$this->db->where('username', $_SESSION['username']);
		return $this->db->update('users', $post);
		
	}
	
	
public function get_edit_user($hp) {
		
		$this->db->select('id');
		$this->db->from('users');
		$this->db->where('username', $hp);
		return $this->db->get()->row('id');
	}
	public function get_edit_sshuser($hp) {
		
		$this->db->select('id');
		$this->db->from('sshuser');
		$this->db->where('created_by', $hp);
		return $this->db->get()->row('id');
	}
	public function edit_sshuser($post) {
	$data = array('hostname' => $post);
		$this->db->where('created_by', $_SESSION['username']);
		return $this->db->update('sshuser', $post);
	}
	
public function edit_image($post) {
		$data = array('username' => $post);
		$this->db->where('username', $_SESSION['username']);
		return $this->db->update('users', $post);
	}
	
	public function get_edit_email($hp) {
		
		$this->db->select('id');
		$this->db->from('users');
		$this->db->where('email', $hp);
		return $this->db->get()->row('id');
	}
	
public function edit_email($post) {
		$data = array('email' => $post);
		$this->db->where('username', $_SESSION['username']);
		return $this->db->update('users', $post);
	}
	public function ServerName($user) {
		return $this->db->get_where('sshuser', array('hostname' => $user))->result_array();
	}
	public function serverid($user) {
		return $this->db->get_where('sshuser', array('serverid' => $user))->result_array();
	}
	
	public function get_dayssh($id=FALSE) {
		if ($id === FALSE) {return $this->db->get('sshuser')->result_array(); }
		
		$this->db->from('sshuser');
		$this->db->where('Id', $id);
		return $this->db->get()->row();
	}

public function get_daysshh($username) {
		
		$this->db->from('users');
		$this->db->where('username', $username);
		return $this->db->get()->row();
	}
	
	public function update_exp($user, $datesm, $saldo1) {
		$this->db->where('username', $user);
		return $this->db->update('sshuser', array('username' => $user, 'expired_at'=>$datesm, 'price'=>$saldo1));
	}
	
	public function update_expp($user, $datesm) {
		$this->db->where('username', $user);
		return $this->db->update('sshuser', array('username' => $user, 'expired'=>$datesm));
	}

public function get_scrip($hp) {
		
		$this->db->select('id');
		$this->db->from('scripvpn');
		$this->db->where('passwd', $hp);
		return $this->db->get()->row('id');
	}
	
public function id_scrip($id) {
		
		$this->db->from('scripvpn');
		$this->db->where('id', $id);
		
		return $this->db->get()->row();
	}
public function scrip($passwd, $expp, $user, $exp) {
		
		$data = array(
            'passwd'   => $passwd,
            'expp'      => $expp,
			'username'   => $user,
			'exp'   => $exp,
			
			
		);
		
		
		return $this->db->insert('scripvpn', $data);
		
	}


	
	public function update_scrip($expp, $exp, $passwd) {
		$this->db->where('passwd', $passwd);
		return $this->db->update('scripvpn', array('exp' => $exp, 'expp'=>$expp));
	}
	
	
	public function view_scrip($user) {
		return $this->db->get_where('scripvpn', array('username' => $user))->result_array();
	}
	
	public function view_scri() {
		return $this->db->get('scripvpn')->result_array();
	}
	
	public function del_scrip($id) {
		$this->db->where('id', $id);
		return $this->db->delete('scripvpn', array('id' => $id));
	}
	
	public function email_scrip($passwd, $wallet) {
		$this->db->where('passwd', $passwd);
		return $this->db->update('scripvpn', array('wallet' => $wallet));
	}
	
public function update_history($user, $aaa, $money) {
		$this->db->where('username', $user);
		return $this->db->insert('histrory', array('username' => $user, 'NumberWallet'=>$aaa, 'money'=>$money));
	}
	
	public function get_Auto($id=FALSE) {
		if ($id === FALSE) {return $this->db->get('sshuser')->result_array(); }
		
		$this->db->from('wallet');
		$this->db->where('Id', $id);
		return $this->db->get()->row();
	}
	
	public function get_AutoSaldo($username) {
		
		$this->db->from('users');
		$this->db->where('username', $username);
		return $this->db->get()->row();
	}

public function edit_saldo($id, $saldo) {
		$this->db->where('id', $id);
		return $this->db->update('users', array('saldo' => $saldo));
	}
	
	public function get_otp($hp) {
		
		$this->db->select('id');
		$this->db->from('histrory');
		$this->db->where('NumberWallet', $hp);
		return $this->db->get()->row('id');
	}
	
public function view_histrory($user) {
		return $this->db->get_where('histrory', array('username' => $user))->result_array();
	}
	
public function updatefile($id, $server, $sim, $pro, $link) {
		$this->db->where('id', $id);
		$data = array(
			'server'   => $server,
			'sim'   => $sim,
			'pro'   => $pro,
			'link'   => $link,
		);
		
	return $this->db->update('ovpn', $data);
	}

public function get_file($id) {
		
		$this->db->from('ovpn');
		$this->db->where('id', $id);
		return $this->db->get()->row();
	}
	
	}