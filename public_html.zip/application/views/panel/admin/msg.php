<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
                   
      <h3>
       ตั้งค่า แจ้งเตือน
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">สร้างแจ้งเตือน</li>
    </ol>
    
        </div>
    </div>
    <div class="well"> 
    <div class="row">
        <center>
           
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			   <?= form_open() ?>
				
				<?php foreach ($this->user_model->view_msg() as $row): ?>
		
				<p>หัวข้อเรื่อง</p>
					<input type="text" name="msg" class="text-center form-control" id="msg" value="<?= $row['msg']?>"  placeholder="ชื่อเรื่อง" />
						
					
				
				
						<p>คำอธิบายต่างๆ</p>
						<textarea type="text"  id="post" class="text-center" name="post" cols="35%" rows="10%" tabindex="10%" placeholder="<?= $row['post']?>" ></textarea>
				
						
					
					
					

						
						
						<input type="submit" class="btn btn-primary form-control" value="อัปเดตข่าวสาร"/>
					
			   </form></div></div>
			<?php endforeach; ?>
		   
		  