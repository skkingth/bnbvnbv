<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
                   
      <h3>
       ตั้งค่าไฟล์ OpenVPN
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">Ovpn Download</li>
    </ol>
    
        </div>
    </div>
    <div class="well"> 
    <div class="row">
        <center>
           
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			   <?= form_open() ?>
				
				<div class="form-group">
						<label for="server">เซิฟร์เวอร์</label>
						<input name="server" class="text-center form-control" id="server" value="<?php if (isset($file)) { echo $file->server;} ?>" type="text"  placeholder="TH1-SMILEVPN" />
						</div>
				
				
				<div class="form-group">
						<label for="sim">ซิมที่รองรับ</label>
						<input type="text" name="sim" class="text-center form-control" value="<?php if (isset($file)) { echo $file->sim;} ?>" id="sim" placeholder="Ais  True Dtac" />
						</div>
					
				
					
						<div class="form-group">
						<label for="pro">ต้องมีโปรโมชั่นอะไร</label>
						<input type="text" name="pro" value="<?php if (isset($file)) { echo $file->pro;} ?>" class="text-center form-control" id="pro" placeholder="TrutID Facebook Viber" />
						</div>
						
						<div class="form-group">
						<label for="email">ใส่ลิ้งไฟล์ OVPN</label>
						<input type="text" name="link" class="text-center form-control" value="<?php if (isset($file)) { echo $file->link;} ?>" id="link" placeholder="http://domain/download.ovpn" />
						</div>
						
					
					<?php if (isset($file)) { ?>
						<input type="submit" class="btn btn-primary form-control" value="อัปเดต"/>
					<?php } else { ?>
						<input type="submit" class="btn btn-primary form-control" value="เพิ่มไฟล์"/>
						<?php } ?>
			   </form></div>
			
		   
		  <center>
						
					<h4 class="page-header">ลิ้งดาวน์โหลดที่กำหนดใว้</h4>
					
					<div class="table-responsive">
                  <table class="table table-hover">
						<thead>
							<tr><th><center>เซิฟร์เวอร์</center></th><th><center>ซิมที่ใช้งาน</center></th><th><center>โปรที่ต้องสมัคร</center></th><th><center>download</center></th><th><center>แก้ไข</center></th><th><center>ลบออก</center></th></tr>
                        </thead>
                        <tbody>
                            
							
					
						
							
							
							<?php if (!empty($this)):?>
						<?php foreach ($this->user_model->view_ovpn() as $row): ?>
							<tr>
								
								
								<td><center><?= $row['server']?></center></td>
								
								<td><center><?= $row['sim']?></center></td>
								<td><center><?= $row['pro']?></center></td>
								<td><center><a href="<?= $row['link']?>"><span class="fa fa-download"></span></a></center></td>
									<td><center><a href="<?=base_url('admin/editfile/'.$row['id'])?>"><span class="fa fa-edit fa-sm"></span></a></center></td>
<td><center><a href="<?=base_url('admin/del_ovpn/'.$row['id'])?>"><span class="fa fa-trash-o fa-sm"></span></a></center></td>
									
							</tr>
							
								
							
								
						<?php endforeach; ?>
							
							<?php else: ?>
							
								
								
								<center><font color="red">ยังไม่มีไฟล์ ที่กำหนด</font></center>
								
					<?php endif; ?>
						
						</tbody>
					</table></div>
			</div>
			</div>
			</div>
   
    </center>
    
    
    
				