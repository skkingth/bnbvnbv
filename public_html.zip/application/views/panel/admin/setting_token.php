<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
                   
      <h3>
       ตั้งค่า แจ้งเตือนไลน์
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">แจ้งเตือนไลน์</li>
    </ol>
    
        </div>
    </div>
    <div class="well"> 
    <div class="row">
        <center>
           
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			   <?= form_open() ?>
				<?php foreach ($this->user_model->view_token() as $row): ?>
				<div class="form-group">
						<label for="login">แจ้งเตือนสมัคสมาชิกกับเปลียนรหัสผ่าน</label>
						<input name="login" class="text-center form-control" id="login" type="text" value="<?= $row['login']?>" placeholder="ใส่ Token Line" />
						</div>
				
				
				<div class="form-group">
						<label for="phone">แจ้งเตือนเมื่อเติมเครดิต Auto Wallet</label>
						<input type="text" name="wallet" class="text-center form-control" id="wallet" value="<?= $row['wallet']?>" placeholder="ใส่ Token Line" />
						</div>
					
				
					
						<div class="form-group">
						<label for="email">แจ้งเตือนมีการเช่าวีพีเอ็น</label>
						<input type="text" name="add_vpn" class="text-center form-control" id="add_vpn" value="<?= $row['add_vpn']?>" placeholder="ใส่ Token Line" />
						</div>
						
					
					
						<input type="submit" class="btn btn-primary form-control" value="อัปเดตข้อมูล"/>
					
			   </form></div></div>
			<?php endforeach; ?>
		   
		  