<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h3 class="page-header">เพิ่มเซิฟร์เวอร์
            </h3>
            <ol class="breadcrumb">
        <li><a href="<?= base_url('panel/admin/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-th-list fa-fw"></i> หน้าหลัก</a></li>
		<li class="active">เพิ่มเซิฟร์เวอร์</li>
    </ol>
        </div>
    </div>
    <div class="row">
            <div class="col-lg-12">
				<?php if (isset($message)) { echo $message; }?>               
            </div>
        <div class="col-md-6">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <i class="fa fa-gear fa-fw"></i> ตั้งค่าเซิฟร์เวอร์
                </div>
                <div class="panel-body">
                    <form action="<?= base_url('panel/admin/'.$_SESSION['username'].'/'.'addserver') ?>" method="POST">
                        <div class="form-group">
                            <label>ตั้งชื่อ</label>
                            <input class="form-control" placeholder="Server Demo" name="ServerName" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>ชื่อแทนเซิฟร์เวอร์</label>
                            <input class="form-control" placeholder="Location Demo" name="Location" type="text" required>     
                        </div>
                        <div class="form-group">
                            <label>โฮส IP</label>
                            <input class="form-control" placeholder="192.168.1.1 atau www.example-server.com" name="HostName" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>ราคา</label>
                            <div class="input-group">
                                <span class="input-group-addon">THB. </span>
                                <input class="form-control" placeholder="1000" name="Price" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>จำนวนวันใช้งาน</label>
                            <input class="form-control" placeholder="Expired" name="Expired" type="number">
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านเซิฟร์เวอร์</label>
                            <input class="form-control" placeholder="Server Passwd" name="RootPasswd" type="text">
                        </div>
                        
                          <div class="col-xs-6">
     
                        <input type="submit" class="btn btn-info form-control" value="เพิ่มเซิฟร์เวอร์">
                            </div>
                            <div class="col-xs-6">
                        <a href="<?= base_url('panel/admin/'.$_SESSION['username'].'/'.'server') ?>" class="btn btn-warning form-control">ย้อนกลับ</a>
                 </div>
   </form>
                </div>
            </div>
        </div>
    </div>
</div>
