<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<div id="page-wrapper">
			<div class="row"><div class="col-lg-12"><h3 class="page-header">แก้ไข เซิฟร์เวอร์</h3></div></div>
				<div class="row"><div class="col-lg-12">
					
					<div class="panel panel-default">
						<div class="panel-heading"></div>
						<div class="panel-body">
							<?php if (isset($message)) : ?>
									<?= $message ?>
							<?php endif; ?>
								<?php foreach ($this->user_model->view_asset() as $row): ?>
							<form action="<?= base_url('panel/admin/edit_web/'.$row['id'].'') ?>" method="POST">
								<div class="form-group">
									<label for="ServerName">ชื่อ</label>
									<input type="text" class="form-control" id="ServerName" name="web" value="<?= $row['web']?>">
										<p class="help-block"></p>
								</div>
								<div class="form-group">
									<label for="ServerName">ชื่อแทนเซิฟร์เวอร์</label>
									<input class="form-control" placeholder="Location Demo" name="link" value="<?= $row['link']?>"
										<p class="help-block"></p>
								</div>
								<div class="form-group">
									<label for="ServerName">ชื่อแทนเซิฟร์เวอร์</label>
									<input class="form-control" placeholder="Location Demo" name="groud" value="<?= $row['groud']?>"
										<p class="help-block"></p>
								</div>
								<div class="form-group">
									<label for="email">โฮส IP</label>
									<input type="text" class="form-control" id="png" name="png" value="<?= $row['png']?>"
									<p class="help-block"></p>
								</div>
								
								<div class="form-group">
									<input type="submit" class="btn btn-primary" value="บันทึก">									
									<a href="<?= base_url('panel/administrator/'.$_SESSION['username'].'/'.'server') ?>" class="btn btn-default">กลับ</a>
								</div>
							</form>
							<?php endforeach; ?>
						</div>
					</div>
				</div></div><!-- .row -->
		</div>
