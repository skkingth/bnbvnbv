<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
<div class="row"> 
    <div class="col-lg-12"> 
          
      <h3>
       วิธีเติมเครดิต AutoWallet
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-th-list fa-fw"></i> หน้าหลัก</a></li>
		<li class="active">วิธีเติมเครดิต</li>
		</ol>
<div class="panel-body">
	
			  
     <center> 
           <?php foreach ($this->user_model->view_wallet() as $row): ?>
					<?php if (!empty($row['phone'])): ?>
           </div>
           <center>
<?php if (isset($message)) {echo $message; }?>
	<ol class="breadcrumb"><br>
<FONT COLOR='#FF0800' size='5'>เพียงทำตามขันตอน</FONT>
<br><br>
โอนทรูวอเล็ทเข้าบัญชี <?= $row['phone']?><br>
และนำเลขที่อ้างอิงที่ได้มาเพื่อยืนยันรับเครดิต

                     <center>    <h4><a href="/seller/AutoWallet" class="btn btn-warning" >ยืนยันเลขที่อ้างอิงเพื่อเติมเครดิต</a></h4></center>
                                      
<img src="/asset/imega/let.jpg" width="310" height="350" ></a>
  
                            
                                </form> 
<p>&nbsp;</p> 
<?php endif; ?>	
			   <?php endforeach; ?> 

<font color="#FF4300">
โปรดทราบ.. </font>
<font color="#666666">ถ้าหากเติมไม่ผ่านโปรดติดต่อแอดมินโดยเร็วที่สุด
</font><br><br>

</ol><br><br>
                                        


     
 <?php foreach ($this->user_model->view_asset() as $row): ?>
           
                <div align="center">© FB Groups <a href="<?= $row['groud']?>">เข้าร่วมกลุ่มเฟสบุค</a></div>
               
              <center>
					<a href="<?= $row['link']?>">ติดต่อแอดมินคลิกที่นี่...</a>
					
           <?php endforeach; ?>
	</center>

 <p>&nbsp;</p>
</div>

