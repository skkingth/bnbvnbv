<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*
 * Copyright (c) 2006-2017 Adipati Arya <jawircodes@gmail.com>,
 * 2006-2017 http://sshcepat.com
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
class Admin extends CI_Controller {
	public function __construct() {
		parent::__construct();
		
		$this->load->model('user_model');
		$this->load->helper('url_helper');
		$this->load->library(array('session'));
	}
	private function _set_view($file, $init) {
		$data = new stdClass();
		$data -> msg = $this->user_model->seller_notify();
		$this->load->view('panel/base/page_header', $data);
		$this->load->view($file, $init);
        $this->load->view('panel/base/footer');
	}
	public function notify() {
	if ($_SESSION['is_admin'] === true) {
			
			$data = new stdClass();
			$data -> msg = $this->user_model->seller_notify();
			
			$this->_set_view('panel/admin/message', $data);
		}
		else {redirect(base_url('login/login'));}
	}
	public function admin($user=FALSE) {
		
		
		
		if ($_SESSION['username'] === $user && $_SESSION['is_admin'] === true) {
			
			$data = new stdClass();
			$data -> server = $this -> user_model -> get_hostname();
			$this->_set_view('panel/admin/servers', $data);
		}
		else {redirect(base_url('login/login'));}
	}
	private function __validate_post($data) {
		return !empty($data['ServerName']) && !empty($data['Location']) && !empty($data['HostName']) && !empty($data['RootPasswd']);
	}
	public function server( $cmd ) {
		$data = new stdClass();
		
		if ( $cmd == 'addserver' ) {
			if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
				
				if ($_POST) {
					if ( $this->__validate_post($_POST) ) {
						if ( $this->user_model->create_hostname($_POST) ) {
							$data->message = '<div class="btn btn-success">เซิฟร์เวอร์พร้อมให้เช่า</div>';
							$data->server = $this -> user_model -> get_hostname();
							$this->_set_view('panel/admin/servers', $data);
							return;
						}else{ $data->message='<div class="btn btn-danger">Terjadi kesalahan saart penambahan server</div>';}
					} else { $data->message='<div class="btn btn-warning">Form harus diisi lengkap</div>'; }
					
				}
				$this->_set_view('panel/admin/addserver', $data);
			} else { redirect(base_url('login/login')); }
		}
		else if ($cmd == 'server') {
			if (isset($_SESSION['username']) && $_SESSION['is_admin'] === true) {
				$data->server = $this->user_model->get_hostname();
				$this->_set_view('panel/admin/servers', $data);
			} else { redirect(base_url('login/login')); }
		}
		else { show_404(); }
	}
	public function edit($id) {
	  $data = new stdClass();
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			$data -> server = $this->user_model->get_hostname($id);
			$this->_set_view('panel/admin/edit', $data);
			if($_POST) {
				if ($this->__validate_post($_POST)) {
					if ($this -> user_model->update_server($_POST, $id)) {
						
						redirect(base_url('panel/admin/'.$_SESSION['username'].''));
					
				
				} else {
					
					$data->message = '<div class="btn btn-danger">Form tidak boleh ada yg dikosongkan</div>';
					$data -> server = $this->user_model->get_hostname($id);
					$this->_set_view('panel/admin/edit', $data);
					}
					}
			}
			
		}
		else { redirect(base_url('login/login')); }
	}
	/*
	public function lock($id, $cmd) {
		$data = new stdClass();
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			if ($cmd === 'lock') {
				if ($this -> user_model->update_server(array('Status' => false), $id)) {
					$data -> message = '<div class="btn btn-danger">Server berhasil di lock</div>';
					$this->admin($_SESSION['username']);
				}
			}
			elseif ($cmd === 'unlock') {
				if ($this -> user_model->update_server(array('Status' => true), $id)) {
					$data -> message = '<div class="btn btn-success">Success server berhasil di unlock </div>';
					$this->admin($_SESSION['username']);
				}
			}
			elseif ($cmd === 'del') {
				if ($this -> user_model->delete_server($id)) {
					$this->admin($_SESSION['username']);
				}
			}
			else {show_404();} 
		}
	  else { redirect(base_url('login/login')); }
	}
	*/
	public function lock($id) {
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
				if ($this -> user_model->update_server(array('Status' => false), $id)) {
					$data = new stdClass();
				$data -> server = $this -> user_model -> get_hostname();
				$data->message='<div class="btn btn-danger">ล็อกเซิฟร์เรียบร้อย</div>';
						$this->_set_view('panel/admin/servers', $data);
					}
				}
				else { redirect(base_url('login/login')); }
			}
			public function unlock($id) {
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
				if ($this -> user_model->update_server(array('Status' => true), $id)) {
					$data = new stdClass();
				$data -> server = $this -> user_model -> get_hostname();
				$data->message='<div class="btn btn-success">ปลดล็อกเซิฟร์เรียบร้อย</div>';
						$this->_set_view('panel/admin/servers', $data);
					}
				}
				else { redirect(base_url('login/login')); }
			}
	public function cekuser($id=FALSE) {
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			$data = new StdClass();
			$data->server=$this->user_model->get_hostname($id);
			$data->user=$this->user_model->get_user_ssh($id);
			
			$this->_set_view('panel/admin/accounts', $data);
		}
		else { redirect(base_url('login/login')); }
	}
	
	
	public function delet_account($id) {
		$this->load->library('sshcepat');
		if (empty($this->user_model->id_ssh($id)->hostname)) { Show_404(); }
		$data = array (
			'hostname' => $this->user_model->id_ssh($id)->hostname,
			'rootpass' => $this->user_model->get_hostname($this->user_model->id_ssh($id)->serverid)->RootPasswd,
			'id' => $this->user_model->get_hostname($this->user_model->id_ssh($id)->serverid)->Id,
			'username' => $this->user_model->id_ssh($id)->username
		);
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			if ($this->user_model->delete_user_ssh($id)) {
					if ($this->sshcepat->deletAccount($data)) {
						redirect(base_url('admin/cekuser/'.$data['id']));
						
					} else {echo 'Root passwd wrong!';}
			}
		}
		else { redirect(base_url('login/login')); }
		
	}
	
	public function del_account($id) {
		$this->load->library('sshcepat');
		if (empty($this->user_model->id_ssh($id)->hostname)) { Show_404(); }
		$data = array (
			'hostname' => $this->user_model->id_ssh($id)->hostname,
			'rootpass' => $this->user_model->get_hostname($this->user_model->id_ssh($id)->serverid)->RootPasswd,
			'id' => $this->user_model->get_hostname($this->user_model->id_ssh($id)->serverid)->Id,
			'username' => $this->user_model->id_ssh($id)->username
		);
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			if ($this->user_model->delete_user_ssh($id)) {
					if ($this->sshcepat->deletAccount($data)) {
						redirect(base_url('admin/view_account'));
						
					} else {echo 'Root passwd wrong!';}
			}
		}
		else { redirect(base_url('login/login')); }
		
	}
	//
	public function setting_web() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			$this->form_validation->set_rules('web','No. web', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('link', 'link', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('groud','no groud', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('png','png', 'trim|required|min_length[4]');
			
			
			
			if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$data->asset=$this->user_model->view_asset();
				$this->_set_view('panel/admin/setting_web', $data);
			} else {
				$post = array (
						'web' => $this->input->post('web'),
						'link' => $this->input->post('link'),
						'groud' => $this->input->post('groud'),
						 'png' => $this->input->post('png'),
						
						
				);
				if (!$this->user_model->get_hp($this->input->post('web'))) {
					if ($this->user_model->asset($post)) {
						$data = new stdClass();
						$data->asset=$this->user_model->view_asset();
						$data->message='<div class="btn btn-success">กำหนดค่าเรียบร้อย</div>';
						$this->_set_view('panel/admin/setting_web', $data);
						
					} else {echo 'Database error';} 
				}
				else {
					redirect(base_url('admin/setting_web'));
				}
			}
		}
		else {redirect(base_url('login/login'));}
	}

	
	
	//wallet
	public function setting_wallet() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			$this->form_validation->set_rules('phone','phone', 'trim|required|min_length[10]');
			$this->form_validation->set_rules('pin', 'pin',  'trim|required|min_length[4]');
			$this->form_validation->set_rules('username','username', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('passwd', 'passwd', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('ewallet','ewallet', 'trim|required|min_length[1]');

			
			if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$data->wallet=$this->user_model->view_wallet();
				$this->_set_view('panel/admin/setting_wallet', $data);
			} else {
				$post = array (
						'phone' => $this->input->post('phone'),
						'pin' => $this->input->post('pin'),
						'username' => $this->input->post('username'),
						'passwd' => $this->input->post('passwd'),
						'ewallet' => $this->input->post('ewallet'),
						

				);
				
					if ($this->user_model->wallet($post)) {
						$data = new stdClass();
						$data->wallet=$this->user_model->view_wallet();
						$data->message='<div class="btn btn-success">อัปเดตเรียบร้อย</div>';
						$this->_set_view('panel/admin/setting_wallet', $data);
						
					} else {echo 'Database error';} 
				
			}
		}
		else {redirect(base_url('login/login'));}
	}
	
	
	
	//token_line
	public function setting_token() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			$this->form_validation->set_rules('login','login', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('wallet','wallet', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('add_vpn','add_vpn', 'trim|required|min_length[4]');
			
         if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$data->wallet=$this->user_model->view_token();
				$this->_set_view('panel/admin/setting_token', $data);
			} else {
				$post = array (
						'login' => $this->input->post('login'),
						'wallet' => $this->input->post('wallet'),
						'add_vpn' => $this->input->post('add_vpn'),
						 );
				if (!$this->user_model->get_token($this->input->post('wallet'))) {
					if ($this->user_model->token($post)) {
						$data = new stdClass();
						$data->wallet=$this->user_model->view_token();
						$data->message='<div class="btn btn-success">กำหนดค่าเรียบร้อย</div>';
						$this->_set_view('panel/admin/setting_token', $data);
						
					} else {echo 'Database error';} 
				}
				else {
					redirect(base_url('admin/setting_token'));
				}
			}
		}
		else {redirect(base_url('login/login'));}
	}
	
	
	
	
	public function view_users() {
     $this->load->helper('form');
		$this->load->library('form_validation');
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
       $this->form_validation->set_rules('username','username', 'trim|required|min_length[4]');
		
				if ($this->form_validation->run() === false) {
					$data = new stdClass();
				$this->_set_view('panel/admin/view_users', $data);
				
					} else {
				$post = array (
						'username' => $this->input->post('username'),
						
						 );
						$data = new stdClass();
						$data->sshuser=$this->input->post('username');
				$this->_set_view('panel/admin/view_users', $data);
				
		}
		}
		else {redirect(base_url('login/login'));}
	}
	
	
	public function view_account() {
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			$data = new stdClass();
			$data->sshuser=$this->user_model->view_account();
		    $this->_set_view('panel/admin/view_account', $data);
				
		
		}
		else { redirect(base_url('login/login')); }
	}
	
	//download ovpn
	public function download() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			$this->form_validation->set_rules('server','server', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('sim','sim', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('pro','pro', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('link','link', 'trim|required|min_length[4]');
			
         if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$data->wallet=$this->user_model->view_ovpn();
				$this->_set_view('panel/admin/setting_ovpn', $data);
			} else {
				$post = array (
						'server' => $this->input->post('server'),
						'sim' => $this->input->post('sim'),
						'pro' => $this->input->post('pro'),
						'link' => $this->input->post('link'),
						 );
				if (!$this->user_model->get_ovpn($this->input->post('link'))) {
					if ($this->user_model->ovpn($post)) {
						$data = new stdClass();
						$data->ovpn=$this->user_model->view_ovpn();
						$data->message='<div class="btn btn-success">เพิ่มไฟล์เรียบร้อย</div>';
						$this->_set_view('panel/admin/setting_ovpn', $data);
						
					} else {echo 'Database error';} 
					
				}
				else {
					
					redirect(base_url('admin/download'));
				}
			}
		}
		else {redirect(base_url('login/login'));}
	}
	
	public function del_ovpn($id) {
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			if ($this->user_model->del_ovpn($id)) {
				
				redirect(base_url('admin/download'));
			}
		}
		else { redirect(base_url('login/login')); }
	}
	//msg
	public function msg() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			$this->form_validation->set_rules('msg','msg', 'trim|required|min_length[4]');
			$this->form_validation->set_rules('post','post', 'trim|required|min_length[4]');
			
         if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$data->wallet=$this->user_model->view_msg();
				$this->_set_view('panel/admin/msg', $data);
			} else {
				$post = array (
						'msg' => $this->input->post('msg'),
						'post' => $this->input->post('post'),
						 );
				if (!$this->user_model->get_msg($this->input->post('msg'))) {
					if ($this->user_model->msg($post)) {
						$data = new stdClass();
						$data->ovpn=$this->user_model->view_msg();
						$data->message='<div class="btn btn-success">กำหนดค่าเรียบร้อย</div>';
						$this->_set_view('panel/admin/msg', $data);
						
					} else {echo 'Database error';} 
				}
				else {
					redirect(base_url('admin/msg'));
				}
			}
		}
		else {redirect(base_url('login/login'));}
	}
	
	public function del($id) {
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			if ($this->user_model->delete_server($id)) {
				$data = new stdClass();
				$data -> server = $this -> user_model -> get_hostname();
				$data->message='<div class="btn btn-danger">ลบเซิฟร์เรียบร้อย</div>';
						$this->_set_view('panel/admin/servers', $data);
			}
		}
		else { redirect(base_url('login/login')); }
	}
	
public function edit_saldo($id) {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			$this->form_validation->set_rules('saldo', 'saldo', 'trim|required|min_length[1]', array('min_length' => 'โปรดใช้รหัสผ่านอย่างน้อย 1 อักษร', 'required' => 'ใส่จำนวนเครดิต'  ));
		    $this->form_validation->set_rules('chek', 'chek', 'trim|required|min_length[1]', array('min_length' => 'โปรดติกเลือกรูปแบบการทำงาน', 'required' => 'โปรดติกเลือกรูปแบบการทำงาน'  ));
		    
         if ($this->form_validation->run() === false) {
				$data = new stdClass();
				
					 $data->user = $this->user_model->get_user($id);
					 
					
				$this->_set_view('panel/admin/view_users', $data);
			} else {
				$saldo = $this->input->post('saldo');
				$chek = $this->input->post('chek');
				if (1 == $chek) {
				$post = array (
						'saldo' => $this->user_model->get_user($id)->saldo + $saldo,
						
						 );
				} else {
				$post = array (
						'saldo' => $saldo,
						
						 );
				}
					if ($this->user_model->edit_saldo($id, $post['saldo'])) {
					    $user = $this->user_model->get_user($id) -> username;
						$data = new stdClass();
					
					 
					    $data->user = $this->user_model->get_user($id);
						$data->message='<div class="btn btn-success"><center>อัปเดตเครดิตให้ '.$user.' เรียบร้อย</center> </div> ';
						$this->_set_view('panel/admin/view_users', $data);
						
					} else {echo 'Database error';} 
							
			}
		}
		else {redirect(base_url('login/login'));}
	}
	
public function editfile($id) {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if ( isset($_SESSION['username']) && $_SESSION['is_admin'] === true ) {
			$this->form_validation->set_rules('server','server', 'trim|required|min_length[1]');
			$this->form_validation->set_rules('sim','sim', 'trim|required|min_length[1]');
			$this->form_validation->set_rules('pro','pro', 'trim|required|min_length[1]');
			$this->form_validation->set_rules('link','link', 'trim|required|min_length[1]');
			
         if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$data->file=$this->user_model->get_file($id);
				$this->_set_view('panel/admin/setting_ovpn', $data);
			} else {
				$post = array (
						'server' => $this->input->post('server'),
						'sim' => $this->input->post('sim'),
						'pro' => $this->input->post('pro'),
						'link' => $this->input->post('link'),
						 );
				
					if ($this->user_model->updatefile($id, $post['server'], $post['sim'], $post['pro'], $post['link'])) {
						echo '<script>alert("อัปเดตข้อมูลเรียบร้อย");</script>';
echo "<meta http-equiv='refresh' content='0;url=/admin/download'>";
						
					} else {echo 'Database error';} 
					
				
			}
		}
		else {redirect(base_url('login/login'));}
	}
	
}
